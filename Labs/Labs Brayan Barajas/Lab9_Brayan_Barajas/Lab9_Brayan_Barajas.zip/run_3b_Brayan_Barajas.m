f=@(x) x*log(x);
a=1;
b=2;
M=2;
pa=my_simpson_function_Brayan_Barajas(f,a,b,M)

