f=@(x) x*log(x);
a=1;
b=2;
M=4;
pa=my_trapezoidal_function_Brayan_Barajas(f,a,b,M)
